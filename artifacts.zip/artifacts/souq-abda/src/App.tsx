import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import Home from '@/pages/Home';
import AdminSellerApplications from '@/pages/AdminSellerApplications';
import AddProduct from '@/pages/AddProduct';
import SellerLogin from '@/pages/SellerLogin';
import SellerDashboard from '@/pages/SellerDashboard';

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/admin/seller-applications" component={AdminSellerApplications} />
      <Route path="/add-product" component={AddProduct} />
      <Route path="/seller-login" component={SellerLogin} />
      <Route path="/seller-dashboard" component={SellerDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
