import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sellerApplicationsTable = pgTable("seller_applications", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  projectName: text("project_name").notNull(),
  whatsapp: text("whatsapp").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("pending"),
  accessToken: text("access_token").unique(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertSellerApplicationSchema = createInsertSchema(
  sellerApplicationsTable,
).omit({ id: true, createdAt: true });
export type InsertSellerApplication = z.infer<
  typeof insertSellerApplicationSchema
>;
export type SellerApplication = typeof sellerApplicationsTable.$inferSelect;
