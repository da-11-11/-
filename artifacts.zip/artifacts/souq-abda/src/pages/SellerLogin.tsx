import { useState } from "react";
import { useLocation } from "wouter";
import { useSellerLogin } from "@workspace/api-client-react";
import { ShoppingBag, KeyRound, ArrowLeft } from "lucide-react";

export default function SellerLogin() {
  const [, navigate] = useLocation();
  const [token, setToken] = useState("");
  const [error, setError] = useState("");

  const { mutate: login, isPending } = useSellerLogin({
    mutation: {
      onSuccess: (seller) => {
        sessionStorage.setItem("sellerToken", seller.accessToken);
        sessionStorage.setItem("sellerProfile", JSON.stringify(seller));
        navigate("/seller-dashboard");
      },
      onError: () => {
        setError("رمز الدخول غير صحيح، يرجى التحقق والمحاولة مجدداً.");
      },
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!token.trim()) {
      setError("يرجى إدخال رمز الدخول.");
      return;
    }
    login({ data: { token: token.trim() } });
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-amber-50 flex items-center justify-center py-12 px-4"
      dir="rtl"
    >
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center gap-2">
            <div className="bg-primary/10 p-3 rounded-2xl">
              <ShoppingBag className="w-8 h-8 text-primary" />
            </div>
            <span className="text-3xl font-bold bg-gradient-to-l from-primary to-secondary bg-clip-text text-transparent">
              سوق أبدع
            </span>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <KeyRound className="w-8 h-8 text-orange-500" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">دخول البائعين</h1>
            <p className="text-gray-500 text-sm mt-2 leading-relaxed">
              أدخل رمز الدخول السري الذي حصلت عليه بعد قبول طلبك
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                رمز الدخول السري
              </label>
              <input
                type="text"
                value={token}
                onChange={(e) => setToken(e.target.value.toUpperCase())}
                placeholder="مثال: AB3C7X"
                maxLength={8}
                dir="ltr"
                className="w-full px-4 py-4 rounded-2xl border border-gray-200 focus:border-orange-400 focus:ring-4 focus:ring-orange-100 outline-none transition-all text-center text-2xl font-bold tracking-[0.4em] font-mono placeholder:text-gray-300 placeholder:text-base placeholder:tracking-normal"
                autoFocus
                autoComplete="off"
                autoCapitalize="characters"
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-xl px-4 py-3 text-center font-medium">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isPending || !token.trim()}
              className="w-full bg-gradient-to-r from-secondary to-primary text-white font-bold py-4 rounded-2xl transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-primary/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0 text-lg"
            >
              {isPending ? "جارٍ التحقق..." : "دخول"}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-100 text-center">
            <a
              href="/"
              className="inline-flex items-center gap-1.5 text-sm text-gray-400 hover:text-primary transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              العودة إلى المتجر
            </a>
          </div>
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          هل لم تتلقَّ رمزك بعد؟ يتواصل معك الفريق بعد مراجعة طلبك.
        </p>
      </div>
    </div>
  );
}
