import { useState } from "react";
import { useListSellerApplications, useUpdateSellerApplicationStatus } from "@workspace/api-client-react";
import { getListSellerApplicationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { categories } from "@/data";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Store, Inbox, Lock, CheckCircle2, XCircle, Clock, Copy, Check } from "lucide-react";

function categoryLabel(id: string) {
  return categories.find((c) => c.id === id)?.label ?? id;
}

function StatusBadge({ status }: { status: string }) {
  if (status === "approved") {
    return (
      <Badge className="bg-green-100 text-green-700 border-green-200 hover:bg-green-100 flex items-center gap-1 w-fit">
        <CheckCircle2 className="w-3 h-3" />
        مقبول
      </Badge>
    );
  }
  if (status === "rejected") {
    return (
      <Badge className="bg-red-100 text-red-600 border-red-200 hover:bg-red-100 flex items-center gap-1 w-fit">
        <XCircle className="w-3 h-3" />
        مرفوض
      </Badge>
    );
  }
  return (
    <Badge variant="secondary" className="bg-amber-50 text-amber-600 border-amber-200 flex items-center gap-1 w-fit">
      <Clock className="w-3 h-3" />
      قيد المراجعة
    </Badge>
  );
}

function CopyTokenButton({ token }: { token: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(token);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      title="انسخ رمز الدخول"
      className="inline-flex items-center gap-1.5 bg-orange-50 hover:bg-orange-100 text-orange-700 border border-orange-200 rounded-lg px-3 py-1.5 text-xs font-mono font-bold transition-all"
    >
      <span dir="ltr" className="tracking-widest">{token}</span>
      {copied ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
    </button>
  );
}

export default function AdminSellerApplications() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  const queryClient = useQueryClient();
  const { data: applications, isLoading, isError } = useListSellerApplications();
  const { mutate: updateStatus, isPending } = useUpdateSellerApplicationStatus({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSellerApplicationsQueryKey() });
      },
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "admin2026") {
      setIsAuthenticated(true);
      setLoginError("");
    } else {
      setLoginError("كلمة المرور غير صحيحة، يرجى المحاولة مجدداً.");
    }
  };

  const handleAction = (id: number, action: "approved" | "rejected") => {
    updateStatus({ id, data: { status: action } });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12" dir="rtl">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 max-w-md w-full">
          <div className="flex flex-col items-center justify-center mb-6">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
              <Lock className="w-8 h-8 text-orange-500" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">الإدارة المركزية</h1>
            <p className="text-gray-500 text-sm mt-2 text-center">
              يرجى إدخال كلمة المرور للوصول إلى طلبات بائعي سوق أبدع
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="كلمة المرور..."
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none transition-all text-center font-sans tracking-widest"
                dir="ltr"
              />
            </div>
            {loginError && <p className="text-red-500 text-sm text-center font-medium">{loginError}</p>}
            <button
              type="submit"
              className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-xl transition-colors"
            >
              تسجيل الدخول
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12" dir="rtl">
      <div className="container mx-auto px-4 md:px-6 max-w-7xl">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
              <Store className="w-6 h-6 text-orange-500" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">طلبات البائعين</h1>
              <p className="text-gray-500 text-sm">
                مراجعة وقبول المتاجر في منصة سوق أبدع
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAuthenticated(false)}
            className="text-sm font-medium text-gray-500 hover:text-red-500 transition-colors px-4 py-2 rounded-lg hover:bg-red-50"
          >
            تسجيل الخروج
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-x-auto">
          {isLoading ? (
            <div className="p-12 text-center text-gray-500">جارٍ تحميل الطلبات...</div>
          ) : isError ? (
            <div className="p-12 text-center text-red-500">تعذر تحميل الطلبات، يرجى المحاولة مرة أخرى.</div>
          ) : !applications || applications.length === 0 ? (
            <div className="p-12 text-center text-gray-500 flex flex-col items-center gap-3">
              <Inbox className="w-10 h-10 text-gray-300" />
              لا توجد طلبات حتى الآن.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right font-bold text-gray-700">الاسم</TableHead>
                  <TableHead className="text-right font-bold text-gray-700">المشروع</TableHead>
                  <TableHead className="text-right font-bold text-gray-700">واتساب</TableHead>
                  <TableHead className="text-right font-bold text-gray-700">الفئة</TableHead>
                  <TableHead className="text-right font-bold text-gray-700">الوصف</TableHead>
                  <TableHead className="text-right font-bold text-gray-700">تاريخ التقديم</TableHead>
                  <TableHead className="text-center font-bold text-gray-700">الحالة</TableHead>
                  <TableHead className="text-center font-bold text-gray-700">رمز الدخول</TableHead>
                  <TableHead className="text-center font-bold text-gray-700">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {applications.map((app) => (
                  <TableRow key={app.id} className="hover:bg-gray-50 transition-colors">
                    <TableCell className="font-medium">{app.fullName}</TableCell>
                    <TableCell className="font-medium text-orange-600">{app.projectName}</TableCell>
                    <TableCell dir="ltr" className="text-right font-mono text-sm text-gray-600">
                      {app.whatsapp}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-gray-100 hover:bg-gray-200 text-gray-700 border-none">
                        {categoryLabel(app.category)}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <span className="line-clamp-2 text-sm text-gray-500 leading-relaxed">
                        {app.description}
                      </span>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-gray-400">
                      {new Date(app.createdAt).toLocaleDateString("ar-JO", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </TableCell>
                    <TableCell className="text-center">
                      <StatusBadge status={app.status} />
                    </TableCell>
                    <TableCell className="text-center">
                      {app.accessToken ? (
                        <CopyTokenButton token={app.accessToken} />
                      ) : (
                        <span className="text-xs text-gray-300">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      {app.status === "pending" ? (
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleAction(app.id, "approved")}
                            disabled={isPending}
                            className="bg-green-500 hover:bg-green-600 disabled:opacity-50 text-white px-4 py-1.5 rounded-lg text-xs font-bold transition-all shadow-sm hover:shadow-md"
                          >
                            قبول
                          </button>
                          <button
                            onClick={() => handleAction(app.id, "rejected")}
                            disabled={isPending}
                            className="bg-red-50 hover:bg-red-500 disabled:opacity-50 text-red-600 hover:text-white border border-red-200 hover:border-red-500 px-4 py-1.5 rounded-lg text-xs font-bold transition-all"
                          >
                            رفض
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-gray-400">تم البت</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </div>
    </div>
  );
}
