import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useUpdateSellerProfile } from "@workspace/api-client-react";
import type { SellerProfile } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { categories } from "@/data";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ShoppingBag, User, LogOut, CheckCircle2 } from "lucide-react";

const profileSchema = z.object({
  projectName: z.string().min(2, "اسم المشروع مطلوب"),
  whatsapp: z.string().min(10, "رقم واتساب غير صحيح"),
  category: z.string().min(1, "يرجى اختيار الفئة"),
  description: z.string().min(10, "الوصف قصير جداً"),
});

type ProfileForm = z.infer<typeof profileSchema>;

export default function SellerDashboard() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [seller, setSeller] = useState<SellerProfile | null>(null);
  const [saved, setSaved] = useState(false);

  // Read token once from sessionStorage for use in the hook
  const token =
    typeof window !== "undefined"
      ? sessionStorage.getItem("sellerToken") ?? ""
      : "";

  useEffect(() => {
    const storedToken = sessionStorage.getItem("sellerToken");
    const profile = sessionStorage.getItem("sellerProfile");
    if (!storedToken || !profile) {
      navigate("/seller-login");
      return;
    }
    try {
      setSeller(JSON.parse(profile) as SellerProfile);
    } catch {
      navigate("/seller-login");
    }
  }, [navigate]);

  const form = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    values: seller
      ? {
          projectName: seller.projectName,
          whatsapp: seller.whatsapp,
          category: seller.category,
          description: seller.description,
        }
      : undefined,
  });

  // Pass the token header at hook-init time via requestOptions
  const { mutate: updateProfile, isPending } = useUpdateSellerProfile({
    request: { headers: { "x-seller-token": token } },
    mutation: {
      onSuccess: (updated) => {
        sessionStorage.setItem("sellerProfile", JSON.stringify(updated));
        setSeller(updated);
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
        toast({ title: "✅ تم حفظ التغييرات بنجاح" });
      },
      onError: () => {
        toast({
          title: "حدث خطأ",
          description: "تعذّر حفظ التغييرات، يرجى المحاولة مرة أخرى.",
          variant: "destructive",
        });
      },
    },
  });

  const handleLogout = () => {
    sessionStorage.removeItem("sellerToken");
    sessionStorage.removeItem("sellerProfile");
    navigate("/seller-login");
  };

  const onSubmit = (data: ProfileForm) => {
    updateProfile({ data });
  };

  if (!seller) return null;

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Top bar */}
      <nav className="bg-white border-b border-gray-100 shadow-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary/10 p-2 rounded-xl">
              <ShoppingBag className="w-5 h-5 text-primary" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-l from-primary to-secondary bg-clip-text text-transparent">
              سوق أبدع
            </span>
            <span className="text-gray-300 mx-2">|</span>
            <span className="text-sm text-gray-500 font-medium">لوحة البائع</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 bg-gray-50 rounded-full px-3 py-1.5 text-sm text-gray-600">
              <User className="w-4 h-4" />
              <span className="font-medium">{seller.fullName}</span>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-red-500 transition-colors px-3 py-1.5 rounded-full hover:bg-red-50"
            >
              <LogOut className="w-4 h-4" />
              خروج
            </button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 md:px-6 py-10 max-w-2xl">
        {/* Welcome card */}
        <div className="bg-gradient-to-r from-primary to-secondary rounded-3xl p-6 text-white mb-8 shadow-lg shadow-primary/20">
          <p className="text-white/80 text-sm mb-1">أهلاً وسهلاً،</p>
          <h1 className="text-2xl font-bold">{seller.fullName}</h1>
          <p className="text-white/80 text-sm mt-0.5">{seller.projectName}</p>
        </div>

        {/* Profile form */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 md:p-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6">بيانات مشروعك</h2>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="projectName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>اسم المشروع / المتجر</FormLabel>
                    <FormControl>
                      <Input placeholder="مثال: مخبز أم علي" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="whatsapp"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>رقم واتساب للتواصل</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="مثال: 962790000000"
                        dir="ltr"
                        className="text-right"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>فئة المنتجات</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر فئة" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>وصف مشروعك</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="اكتب وصفاً مختصراً عن مشروعك ومنتجاتك..."
                        rows={4}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                disabled={isPending}
                className="w-full bg-gradient-to-r from-secondary to-primary text-white py-5 rounded-2xl text-base font-bold hover:-translate-y-0.5 hover:shadow-lg transition-all"
              >
                {saved ? (
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5" />
                    تم الحفظ!
                  </span>
                ) : isPending ? (
                  "جارٍ الحفظ..."
                ) : (
                  "حفظ التغييرات"
                )}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
