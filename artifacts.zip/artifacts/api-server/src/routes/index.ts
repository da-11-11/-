import { Router, type IRouter } from "express";
import healthRouter from "./health";
import sellerApplicationsRouter from "./seller-applications";
import productsRouter from "./products";

const router: IRouter = Router();

router.use(healthRouter);
router.use(sellerApplicationsRouter);
router.use(productsRouter);

export default router;
