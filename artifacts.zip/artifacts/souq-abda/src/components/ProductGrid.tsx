import { useState } from "react";
import { categories } from "@/data";
import { ProductModal } from "@/components/ProductModal";
import { motion } from "framer-motion";
import { Crown, Heart, PackageSearch, AlertTriangle } from "lucide-react";
import { useListProducts } from "@workspace/api-client-react";
import type { Product } from "@workspace/api-client-react";
import { resolveImageUrl } from "@/lib/utils";

function ProductSkeleton() {
  return (
    <div className="rounded-3xl bg-white border border-gray-100 shadow-sm overflow-hidden animate-pulse">
      <div className="aspect-[4/3] bg-gray-200" />
      <div className="p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="h-6 w-24 bg-gray-200 rounded-full" />
          <div className="h-5 w-16 bg-gray-200 rounded" />
        </div>
        <div className="h-6 w-3/4 bg-gray-200 rounded" />
        <div className="h-4 w-full bg-gray-100 rounded" />
        <div className="h-4 w-2/3 bg-gray-100 rounded" />
      </div>
    </div>
  );
}

export function ProductGrid({ selectedCategory }: { selectedCategory: string | null }) {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const { data: products, isLoading, isError } = useListProducts();

  const filteredProducts = selectedCategory
    ? (products ?? []).filter((p) => p.category === selectedCategory)
    : (products ?? []);

  const categoryLabel = selectedCategory
    ? categories.find((c) => c.id === selectedCategory)?.label
    : null;

  return (
    <section id="featured-products" className="py-16 md:py-24 bg-white relative">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16 max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-4">
            {categoryLabel ? `إبداعات ${categoryLabel}` : "أحدث الإبداعات"}
          </h2>
          <p className="text-gray-500 text-lg">
            اكتشف مجموعة مختارة من أفضل المنتجات اليدوية المصنوعة بشغف وإتقان من قبل حرفيين أردنيين.
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {Array.from({ length: 6 }).map((_, i) => (
              <ProductSkeleton key={i} />
            ))}
          </div>
        ) : isError ? (
          <div className="text-center py-16 text-gray-400 flex flex-col items-center gap-4">
            <AlertTriangle className="w-12 h-12" />
            <p className="text-lg">تعذر تحميل المنتجات، حاول مرة أخرى لاحقاً</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-16 text-gray-400 flex flex-col items-center gap-4">
            <PackageSearch className="w-12 h-12" />
            <p className="text-lg">لا توجد منتجات في هذه الفئة حالياً</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="group cursor-pointer rounded-3xl bg-white border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                onClick={() => setSelectedProduct(product)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setSelectedProduct(product);
                  }
                }}
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-gray-100">
                  <img 
                    src={resolveImageUrl(product.image)} 
                    alt={product.name} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  
                  {product.isVIP && (
                    <div className="absolute top-4 right-4 bg-gradient-to-r from-secondary to-yellow-500 text-gray-900 text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 shadow-md">
                      <Crown className="w-3.5 h-3.5" />
                      <span>مميز</span>
                    </div>
                  )}
                  
                  <button
                    className="absolute top-4 left-4 p-2 bg-white/80 backdrop-blur-md rounded-full text-gray-400 hover:text-red-500 hover:bg-white transition-colors"
                    onClick={(e) => e.stopPropagation()}
                    aria-label="أضف إلى المفضلة"
                  >
                    <Heart className="w-5 h-5" />
                  </button>
                </div>

                <div className="p-5 flex flex-col flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full">
                      {product.seller}
                    </span>
                    <span className="font-bold text-gray-900">{product.price}</span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-1 group-hover:text-primary transition-colors">
                    {product.name}
                  </h3>
                  
                  <p className="text-gray-500 text-sm line-clamp-2 mb-4 flex-1">
                    {product.shortDescription}
                  </p>

                  <div className="mt-auto pt-4 border-t border-gray-100">
                    <span className="text-sm font-bold text-primary flex items-center gap-1 group-hover:gap-2 transition-all">
                      عرض التفاصيل
                      <span className="text-lg">←</span>
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      <ProductModal 
        product={selectedProduct} 
        isOpen={!!selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
      />
    </section>
  );
}
