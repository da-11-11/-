import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { MessageCircle, Crown, Info } from "lucide-react";
import { categories } from "@/data";
import type { Product } from "@workspace/api-client-react";
import { resolveImageUrl } from "@/lib/utils";

export function ProductModal({ 
  product, 
  isOpen, 
  onClose 
}: { 
  product: Product | null; 
  isOpen: boolean; 
  onClose: () => void 
}) {
  if (!product) return null;

  const handleWhatsApp = () => {
    const text = encodeURIComponent(`مرحباً، أنا مهتم بمنتج "${product.name}" المعروض في سوق أبدع.`);
    window.open(`https://wa.me/${product.sellerPhone}?text=${text}`, '_blank');
  };

  const categoryLabel = categories.find((c) => c.id === product.category)?.label ?? product.category;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl p-0 overflow-hidden bg-white rounded-3xl border-0" aria-describedby={undefined}>
        <DialogTitle className="sr-only">{product.name}</DialogTitle>
        <div className="flex flex-col md:flex-row h-full max-h-[90vh]">
          {/* Image Section */}
          <div className="w-full md:w-1/2 relative bg-gray-100">
            <img 
              src={resolveImageUrl(product.image)} 
              alt={product.name} 
              className="w-full h-full min-h-[300px] object-cover"
            />
            {product.isVIP && (
              <div className="absolute top-4 right-4 bg-gradient-to-r from-secondary to-yellow-500 text-gray-900 text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1 shadow-lg backdrop-blur-sm border border-yellow-300/30">
                <Crown className="w-3.5 h-3.5" />
                <span>بائع موثوق</span>
              </div>
            )}
          </div>

          {/* Content Section */}
          <div className="w-full md:w-1/2 p-6 md:p-8 flex flex-col justify-between overflow-y-auto">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-primary bg-primary/10 px-3 py-1 rounded-full">
                  {categoryLabel}
                </span>
                <span className="text-2xl font-bold text-gray-900">{product.price}</span>
              </div>
              
              <h2 className="text-2xl md:text-3xl font-extrabold text-gray-900 mb-4 mt-4 leading-tight">
                {product.name}
              </h2>
              
              <div className="flex items-center gap-3 mb-6 pb-6 border-b border-gray-100">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-lg">
                  {product.seller.charAt(0)}
                </div>
                <div>
                  <p className="text-sm text-gray-500">البائع</p>
                  <p className="font-bold text-gray-900 flex items-center gap-1">
                    {product.seller}
                    {product.isVIP && <Crown className="w-4 h-4 text-secondary" />}
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-bold text-lg flex items-center gap-2">
                  <Info className="w-5 h-5 text-gray-400" />
                  تفاصيل المنتج
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {product.description}
                </p>
              </div>
            </div>

            <div className="mt-8 pt-6">
              <Button 
                onClick={handleWhatsApp}
                className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white py-6 text-lg rounded-2xl shadow-lg shadow-[#25D366]/30 transition-transform hover:-translate-y-1 flex items-center justify-center gap-2 font-bold"
              >
                <MessageCircle className="w-6 h-6" />
                اطلب عبر واتساب
              </Button>
              <p className="text-center text-xs text-gray-400 mt-3 flex items-center justify-center gap-1">
                تواصل مباشر مع البائع بدون وسطاء
              </p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
