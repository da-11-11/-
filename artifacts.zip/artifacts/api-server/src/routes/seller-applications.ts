import { Router, type IRouter } from "express";
import {
  CreateSellerApplicationBody,
  CreateSellerApplicationResponse,
  ListSellerApplicationsResponse,
  UpdateSellerApplicationStatusBody,
  UpdateSellerApplicationStatusResponse,
  SellerLoginBody,
  SellerLoginResponse,
  UpdateSellerProfileBody,
  UpdateSellerProfileResponse,
} from "@workspace/api-zod";
import { db, sellerApplicationsTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";

const router: IRouter = Router();

/** Generate a 6-char uppercase alphanumeric access token */
function generateAccessToken(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no ambiguous 0/O/1/I
  let token = "";
  for (let i = 0; i < 6; i++) {
    token += chars[Math.floor(Math.random() * chars.length)];
  }
  return token;
}

router.post("/seller-applications", async (req, res) => {
  const parsed = CreateSellerApplicationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "بيانات غير صحيحة" });
    return;
  }

  const [created] = await db
    .insert(sellerApplicationsTable)
    .values(parsed.data)
    .returning();

  res.status(201).json(CreateSellerApplicationResponse.parse(created));
});

router.get("/seller-applications", async (_req, res) => {
  const applications = await db
    .select()
    .from(sellerApplicationsTable)
    .orderBy(desc(sellerApplicationsTable.createdAt));

  res.json(ListSellerApplicationsResponse.parse(applications));
});

router.patch("/seller-applications/:id/status", async (req, res) => {
  const idParsed = Number(req.params.id);
  if (!Number.isInteger(idParsed) || idParsed <= 0) {
    res.status(400).json({ error: "معرّف غير صحيح" });
    return;
  }

  const parsed = UpdateSellerApplicationStatusBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "الحالة يجب أن تكون approved أو rejected" });
    return;
  }

  // Generate unique token only when approving
  let newToken: string | undefined;
  if (parsed.data.status === "approved") {
    let token = generateAccessToken();
    for (let attempts = 0; attempts < 10; attempts++) {
      const existing = await db
        .select({ id: sellerApplicationsTable.id })
        .from(sellerApplicationsTable)
        .where(eq(sellerApplicationsTable.accessToken, token));
      if (existing.length === 0) break;
      token = generateAccessToken();
    }
    newToken = token;
  }

  const [updated] = await db
    .update(sellerApplicationsTable)
    .set(
      newToken
        ? { status: parsed.data.status, accessToken: newToken }
        : { status: parsed.data.status }
    )
    .where(eq(sellerApplicationsTable.id, idParsed))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "الطلب غير موجود" });
    return;
  }

  res.json(UpdateSellerApplicationStatusResponse.parse(updated));
});

/** POST /seller-login — verify access token */
router.post("/seller-login", async (req, res) => {
  const parsed = SellerLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(401).json({ error: "رمز الدخول مطلوب" });
    return;
  }

  const [seller] = await db
    .select()
    .from(sellerApplicationsTable)
    .where(eq(sellerApplicationsTable.accessToken, parsed.data.token.trim().toUpperCase()));

  if (!seller) {
    res.status(401).json({ error: "رمز الدخول غير صحيح" });
    return;
  }

  res.json(SellerLoginResponse.parse(seller));
});

/** PATCH /seller/profile — update seller project info */
router.patch("/seller/profile", async (req, res) => {
  const token = req.headers["x-seller-token"];
  if (!token || typeof token !== "string") {
    res.status(401).json({ error: "رمز الدخول مطلوب في الترويسة" });
    return;
  }

  const [existing] = await db
    .select()
    .from(sellerApplicationsTable)
    .where(eq(sellerApplicationsTable.accessToken, token.trim().toUpperCase()));

  if (!existing) {
    res.status(401).json({ error: "رمز الدخول غير صحيح" });
    return;
  }

  const parsed = UpdateSellerProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "بيانات غير صحيحة" });
    return;
  }

  const [updated] = await db
    .update(sellerApplicationsTable)
    .set(parsed.data)
    .where(eq(sellerApplicationsTable.id, existing.id))
    .returning();

  res.json(UpdateSellerProfileResponse.parse(updated));
});

export default router;
