import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Link } from "wouter";
import { categories } from "@/data";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  useCreateProduct,
  getListProductsQueryKey,
} from "@workspace/api-client-react";
import { PackagePlus, CheckCircle2 } from "lucide-react";

const formSchema = z.object({
  name: z.string().min(2, "اسم المنتج مطلوب"),
  shortDescription: z.string().min(10, "الوصف المختصر يجب أن يكون 10 أحرف على الأقل"),
  description: z.string().min(10, "الوصف يجب أن يكون 10 أحرف على الأقل"),
  price: z.string().min(1, "السعر مطلوب"),
  seller: z.string().min(2, "اسم المشروع أو المتجر مطلوب"),
  sellerPhone: z.string().min(10, "رقم الواتساب غير صحيح"),
  image: z.string().url("يرجى إدخال رابط صورة صحيح"),
  category: z.string().min(1, "يرجى اختيار فئة"),
});

export default function AddProduct() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      shortDescription: "",
      description: "",
      price: "",
      seller: "",
      sellerPhone: "",
      image: "",
      category: "",
    },
  });

  const createProduct = useCreateProduct();

  function onSubmit(values: z.infer<typeof formSchema>) {
    createProduct.mutate(
      { data: values },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
          setIsSubmitted(true);
          form.reset();
          toast({
            title: "تمت إضافة منتجك بنجاح!",
            description: "أصبح منتجك الآن ظاهراً في السوق.",
          });
        },
        onError: () => {
          toast({
            title: "حدث خطأ",
            description: "تعذر إضافة المنتج، يرجى المحاولة مرة أخرى.",
            variant: "destructive",
          });
        },
      },
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col" dir="rtl">
      <Navbar />
      <main className="flex-1 py-12 md:py-20">
        <div className="container mx-auto px-4 md:px-6 max-w-2xl">
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 text-primary mb-4">
              <PackagePlus className="w-7 h-7" />
            </div>
            <h1 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-3">
              أضف منتجك إلى السوق
            </h1>
            <p className="text-gray-500 text-lg">
              اعرض إبداعك أمام آلاف المتسوقين وابدأ البيع مباشرة عبر واتساب.
            </p>
          </div>

          <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-6 md:p-10">
            {isSubmitted ? (
              <div className="text-center py-12 flex flex-col items-center gap-4">
                <CheckCircle2 className="w-14 h-14 text-green-500" />
                <h2 className="text-2xl font-bold text-gray-900">تمت إضافة منتجك!</h2>
                <p className="text-gray-500">منتجك الآن معروض في الصفحة الرئيسية.</p>
                <div className="flex gap-3 mt-4">
                  <Button asChild className="rounded-full px-6">
                    <Link href="/">عرض السوق</Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="rounded-full px-6"
                    onClick={() => setIsSubmitted(false)}
                  >
                    إضافة منتج آخر
                  </Button>
                </div>
              </div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>اسم المنتج</FormLabel>
                        <FormControl>
                          <Input placeholder="مثال: كيكة التمر الأردنية" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>السعر</FormLabel>
                          <FormControl>
                            <Input placeholder="مثال: ١٥ دينار أردني" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>الفئة</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="اختر فئة المنتج" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories.map((c) => (
                                <SelectItem key={c.id} value={c.id}>
                                  {c.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="shortDescription"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>وصف مختصر</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="جملة قصيرة تظهر في بطاقة المنتج"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>الوصف الكامل</FormLabel>
                        <FormControl>
                          <Textarea
                            rows={4}
                            placeholder="اشرح تفاصيل منتجك، مكوناته، وما يميزه"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="image"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>رابط صورة المنتج</FormLabel>
                        <FormControl>
                          <Input
                            dir="ltr"
                            placeholder="https://example.com/photo.jpg"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="seller"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>اسم المشروع أو المتجر</FormLabel>
                          <FormControl>
                            <Input placeholder="مثال: مخبز أم علي" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="sellerPhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>رقم واتساب للطلبات</FormLabel>
                          <FormControl>
                            <Input
                              dir="ltr"
                              placeholder="9627XXXXXXXX"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={createProduct.isPending}
                    className="w-full py-6 text-lg rounded-2xl font-bold"
                  >
                    {createProduct.isPending ? "جارٍ الإضافة..." : "أضف المنتج"}
                  </Button>
                </form>
              </Form>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
