import heroImg from "@assets/generated_images/hero-souk.jpg";
import { Utensils, Scissors, Gift, Home, Sparkles } from "lucide-react";

export const assets = {
  hero: heroImg,
};

export const categories = [
  { id: "food", label: "طعام منزلي", icon: Utensils, color: "bg-orange-100 text-orange-600 border-orange-200" },
  { id: "crochet", label: "كروشيه", icon: Scissors, color: "bg-rose-100 text-rose-600 border-rose-200" },
  { id: "gifts", label: "هدايا", icon: Gift, color: "bg-purple-100 text-purple-600 border-purple-200" },
  { id: "decor", label: "ديكورات", icon: Home, color: "bg-teal-100 text-teal-600 border-teal-200" },
  { id: "accessories", label: "إكسسوارات", icon: Sparkles, color: "bg-amber-100 text-amber-600 border-amber-200" },
];

