import { Router, type IRouter } from "express";
import {
  CreateProductBody,
  CreateProductResponse,
  ListProductsResponse,
} from "@workspace/api-zod";
import { db, productsTable } from "@workspace/db";
import { desc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/products", async (_req, res) => {
  const products = await db
    .select()
    .from(productsTable)
    .orderBy(desc(productsTable.createdAt), desc(productsTable.id));

  res.json(ListProductsResponse.parse(products));
});

router.post("/products", async (req, res) => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "بيانات غير صحيحة" });
    return;
  }

  const [created] = await db
    .insert(productsTable)
    .values(parsed.data)
    .returning();

  res.status(201).json(CreateProductResponse.parse(created));
});

export default router;
