import { db, productsTable, type InsertProduct } from "@workspace/db";
import { logger } from "./logger";

const starterProducts: InsertProduct[] = [
  {
    name: "كيكة التمر الأردنية الأصيلة",
    shortDescription:
      "كيكة تمر غنية بالمكسرات والكراميل، مخبوزة بحب من مكونات محلية 100%.",
    description:
      "استمتع بطعم الكيكة الأردنية الأصيلة المصنوعة من أجود أنواع التمر والمكسرات. تأتي مغلفة بشكل أنيق وجاهزة للتقديم في المناسبات أو كهدية مميزة. خالية من المواد الحافظة.",
    price: "١٥ دينار أردني",
    isVIP: true,
    seller: "مخبز أم علي",
    sellerPhone: "962790123456",
    image: "images/products/product-cake.jpg",
    category: "food",
  },
  {
    name: "شال كروشيه شتوي ناعم",
    shortDescription:
      "شال دافئ مصنوع يدوياً من خيوط الصوف عالية الجودة بألوان شتوية.",
    description:
      "قطعة فنية فريدة من نوعها، مشغولة يدوياً بعناية فائقة لتمنحك الدفء والأناقة في أيام الشتاء الباردة. يمكن غسله بسهولة دون أن يفقد جودته.",
    price: "٢٠ دينار أردني",
    isVIP: false,
    seller: "إبداعات سناء",
    sellerPhone: "962791234567",
    image: "images/products/product-crochet.jpg",
    category: "crochet",
  },
  {
    name: "صندوق هدايا فاخر",
    shortDescription:
      "صندوق هدايا منسق يدوياً يحتوي على شوكولاتة وورد طبيعي مجفف.",
    description:
      "أفضل طريقة للتعبير عن مشاعرك لمن تحب. الصندوق الخشبي محفور يدوياً ويحتوي على تنسيق مميز من الشوكولاتة الفاخرة والورد المجفف مع بطاقة إهداء مخصصة.",
    price: "٣٥ دينار أردني",
    isVIP: true,
    seller: "لمسة هدايا",
    sellerPhone: "962792345678",
    image: "images/products/product-giftbox.jpg",
    category: "gifts",
  },
  {
    name: "شمعة معطرة بالياسمين",
    shortDescription:
      "شمعة من شمع الصويا الطبيعي معطرة بزيوت الياسمين العطرية.",
    description:
      "شمعة صديقة للبيئة مصنوعة من شمع الصويا الطبيعي، تمنحك إضاءة هادئة ورائحة الياسمين المنعشة التي تدوم طويلاً، لتضفي جواً من الاسترخاء على غرفتك.",
    price: "١٠ دينار أردني",
    isVIP: false,
    seller: "أضواء الطبيعة",
    sellerPhone: "962793456789",
    image: "images/products/product-candle.jpg",
    category: "decor",
  },
  {
    name: "قلادة بتصميم شرقي",
    shortDescription: "قلادة مطلية بالذهب بتصميم مستوحى من التراث العربي.",
    description:
      "إكسسوار فريد يجمع بين الأصالة والمعاصرة. القلادة مصممة بدقة ومطلية بالذهب عيار 18 لتتحمل الاستخدام اليومي دون أن يتغير لونها.",
    price: "٢٥ دينار أردني",
    isVIP: true,
    seller: "جوهرة للفضيات",
    sellerPhone: "962794567890",
    image: "images/products/product-jewelry.jpg",
    category: "accessories",
  },
  {
    name: "مفرش مطرز تقليدي",
    shortDescription: "مفرش طاولة مطرز باليد بنقشات فلاحية أردنية أصلية.",
    description:
      "عمل يدوي متقن استغرق أسابيع لإنجازه. يمثل التراث الأردني العريق بألوانه الزاهية وتفاصيله الدقيقة. يضفي لمسة شرقية رائعة على ديكور منزلك.",
    price: "٤٠ دينار أردني",
    isVIP: true,
    seller: "تراثيات الأردن",
    sellerPhone: "962795678901",
    image: "images/products/product-embroidery.jpg",
    category: "decor",
  },
];

/**
 * Idempotent starter-catalog seed: inserts the initial products only when
 * the products table is empty, so a fresh environment never shows an empty
 * homepage and existing data is never touched.
 */
export async function seedProductsIfEmpty(): Promise<void> {
  const existing = await db.select({ id: productsTable.id }).from(productsTable).limit(1);
  if (existing.length > 0) {
    return;
  }

  await db.insert(productsTable).values(starterProducts);
  logger.info(
    { count: starterProducts.length },
    "Seeded starter product catalog",
  );
}
