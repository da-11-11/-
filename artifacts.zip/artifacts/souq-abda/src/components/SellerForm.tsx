import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { categories } from "@/data";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useCreateSellerApplication } from "@workspace/api-client-react";
import { Store, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

const formSchema = z.object({
  fullName: z.string().min(2, "الاسم الكامل مطلوب"),
  projectName: z.string().min(2, "اسم المشروع مطلوب"),
  whatsapp: z.string().min(10, "رقم الواتساب غير صحيح"),
  category: z.string().min(1, "يرجى اختيار فئة"),
  description: z.string().min(10, "الوصف يجب أن يكون 10 أحرف على الأقل"),
});

export function SellerForm() {
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      projectName: "",
      whatsapp: "",
      category: "",
      description: "",
    },
  });

  const createApplication = useCreateSellerApplication();

  function onSubmit(values: z.infer<typeof formSchema>) {
    createApplication.mutate(
      { data: values },
      {
        onSuccess: () => {
          setIsSubmitted(true);
          form.reset();
          toast({
            title: "تم استلام طلبك وحفظه بنجاح!",
            description: "سنتواصل معك قريباً لتفعيل حسابك كبائع.",
          });
        },
        onError: () => {
          toast({
            title: "حدث خطأ",
            description: "تعذر إرسال طلبك، يرجى المحاولة مرة أخرى.",
            variant: "destructive",
          });
        },
      },
    );
  }

  return (
    <section id="seller-form" className="py-20 md:py-32 bg-gray-50 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="max-w-4xl mx-auto bg-white rounded-[2.5rem] shadow-xl overflow-hidden border border-gray-100 flex flex-col md:flex-row">
          
          {/* Left/Top Content Panel */}
          <div className="md:w-5/12 bg-gradient-to-br from-primary to-secondary p-10 text-white flex flex-col justify-between">
            <div>
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-6 backdrop-blur-sm">
                <Store className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl font-bold mb-4">انضم إلى سوق أبدع كبائع</h2>
              <p className="text-white/80 leading-relaxed text-lg">
                هل تصنع منتجات يدوية مميزة؟ شارك إبداعك مع آلاف المشترين في الأردن وابدأ في تحقيق أرباح من موهبتك.
              </p>
            </div>
            
            <div className="mt-10 space-y-4">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-white/80" />
               <span>ابدأ رحلتك باشتراك رمزي يضمن لك متجراً مستقلاً وحماية لبياناتك</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-white/80" />
                <span>تواصل مباشر مع المشترين</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-white/80" />
                <span>تسويق لمنتجاتك على منصاتنا</span>
              </div>
            </div>
          </div>

          {/* Right/Bottom Form Panel */}
          <div className="md:w-7/12 p-10">
            {isSubmitted ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="h-full flex flex-col items-center justify-center text-center space-y-4 min-h-[400px]"
              >
                <div className="w-20 h-20 bg-green-100 text-green-500 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">شكراً لك!</h3>
                <p className="text-gray-500">تم استلام طلبك بنجاح، سيقوم فريقنا بمراجعته والتواصل معك قريباً.</p>
                <Button 
                  onClick={() => setIsSubmitted(false)}
                  variant="outline" 
                  className="mt-4"
                >
                  إرسال طلب آخر
                </Button>
              </motion.div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>الاسم الكامل</FormLabel>
                          <FormControl>
                            <Input placeholder="أحمد محمد" className="bg-gray-50/50" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="projectName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>اسم المشروع</FormLabel>
                          <FormControl>
                            <Input placeholder="مخبز السعادة" className="bg-gray-50/50" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <FormField
                      control={form.control}
                      name="whatsapp"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>رقم واتساب</FormLabel>
                          <FormControl>
                            <Input placeholder="0790000000" type="tel" className="bg-gray-50/50 text-right" dir="ltr" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>الفئة</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-gray-50/50">
                                <SelectValue placeholder="اختر الفئة..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories.map((cat) => (
                                <SelectItem key={cat.id} value={cat.id}>
                                  {cat.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>وصف مشروعك</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="حدثنا باختصار عن المنتجات التي تصنعها..." 
                            className="resize-none bg-gray-50/50 h-32" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full h-14 text-lg font-bold bg-primary hover:bg-primary/90 text-white rounded-xl mt-4 shadow-lg shadow-primary/20 transition-transform hover:-translate-y-1"
                    disabled={createApplication.isPending}
                  >
                    {createApplication.isPending ? "جارٍ الإرسال..." : "أرسل طلبك الآن"}
                  </Button>
                </form>
              </Form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
